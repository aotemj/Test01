import Vue from "vue";
export var vm = new Vue();
