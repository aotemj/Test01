<template>
	<div>
		登录组件页面
	</div>
</template>

<script>
	export default{
		
	}
</script>

<style scoped>
	
</style>