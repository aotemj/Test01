<template>
	<div>
	<router-link to="/login">登录</router-link>
	<router-link to="/register">注册</router-link>
	<mt-button type="default">default</mt-button>
	<mt-button type="danger">danger</mt-button>
	<mt-button type="danger" size="large">large</mt-button>

	<router-view></router-view>
	</div>
</template>
<script>
	export default{
		data: function(){
			return{
				name:'一杆梅子酒'
			}
		}
	}
</script>
<style scoped>

</style>
