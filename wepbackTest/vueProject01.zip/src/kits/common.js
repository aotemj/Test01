/*提取公共接口前缀*/
export default{
	apidomain:"http://vue.studyit.io"
}
