// 职责：负责管理当前系统中的所有公共的配置
export default{
    apidomain: 'http://vue.studyit.io'
    // apidomain: 'http://127.0.0.1:8899'  // 所有数据api的域名地址
}
