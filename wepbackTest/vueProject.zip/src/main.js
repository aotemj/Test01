import Vue from 'vue';
import App from "./App.vue"
import vueRouter from 'vue-router';
Vue.use(vueRouter);
import login from './components/account/login.vue';
import register from './components/account/register.vue';

/*引入mint-ui*/
import Mint from "mint-ui";
import "../node_modules/mint-ui/lib/style.min.css";
Vue.use(Mint);

/*使用mui*/
import "../statics/mui/css/mui.css";


var router = new vueRouter({
	routes:[
		{path:'/login',component:login},
		{path:'/register',component:register}
	]
});
new Vue({
	el:'#app',
	router:router,
	render:c=>c(App)
})


